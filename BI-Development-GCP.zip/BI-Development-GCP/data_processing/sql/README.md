# 📁 data_processing/sql

This folder contains scripts, pipelines, or resources related to data_processing/sql.
