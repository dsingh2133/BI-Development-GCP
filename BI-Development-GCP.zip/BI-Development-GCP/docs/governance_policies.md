# Data Governance Policies

- Define IAM roles and permissions.
- Audit logging enabled for all GCP services.
- Ensure data privacy and compliance with regulations.
- Set retention policies for raw and processed data.
